//Lab 4 JavaFx
package org.example.lab4;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ItemListApp extends Application {

    private ObservableList<String> items = FXCollections.observableArrayList();
    private ListView<String> listView = new ListView<>(items); // Start listView here

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Item List Application");

        //// Components of input
        TextField nameInput = new TextField();
        nameInput.setPromptText("Enter name");

        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            String name = nameInput.getText().trim();
            if (isValidName(name)) {
                items.add(name);
                nameInput.clear();
            } else {
                showError("Invalid name. Name must start with uppercase letter and be at least 5 characters long.");
            }
        });

        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(e -> {
            String selectedItem = listView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                items.remove(selectedItem);
            }
        });

        // Layout
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.getChildren().addAll(nameInput, addButton, deleteButton, listView);

        Scene scene = new Scene(layout, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private boolean isValidName(String name) {
        return !name.isEmpty() && name.matches("[A-Z].*") && name.length() >= 5;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}